/**
 * 
 */
/**
 * @author samma
 *
 */
module TeamIOTA {
	requires java.sql;
}