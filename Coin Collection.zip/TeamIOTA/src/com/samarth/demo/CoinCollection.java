package com.samarth.demo;

import static java.lang.Integer.parseInt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class CoinCollection {

	public static void main(String[] args)  {
		 Scanner sc= new Scanner(System.in);
		 try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/samarth","root","Shankar95");
			java.sql.Statement stmt=con.createStatement();
			String sql="select * from coins";
			ResultSet rst=stmt.executeQuery(sql);
			PreparedStatement sdmt=con.prepareStatement("insert into coins(CoinDenomination,Country,Year_Of_Minting,Current_Value,Acquire_date) values (?,?,?,?,?)");
			
			boolean line ;  
			//String splitBy = ","; 
			
			
			ArrayList<String> Coins = new ArrayList<String>();//for array list from database
			ArrayList<String> CntList=new ArrayList<String>();//for create list of countries name
			ArrayList<String> YOmList=new ArrayList<String>();// for year of minting
			ArrayList<String> CurrentValueList=new ArrayList<String>(); //for current value list
			while (rst.next()) {
			         Coins.add(rst.getString(1));
			         Coins.add(rst.getString(2));
			         
			         CntList.add(rst.getString(2));
			         
			         Coins.add(rst.getString(3));
			         
			         YOmList.add(rst.getString(3));
			         
			         Coins.add(rst.getString(4));
			         
			         CurrentValueList.add(rst.getString(4));
			         
			         Coins.add(rst.getString(5));
			         Coins.add("\n");
			         }
			
			
			System.out.println("your current database is:");
			System.out.println("[Denomination,Country,Year_of_minting,current_value,acquired_date]");
			System.out.println(Coins);
			int n=0;
			do {
				System.out.println("Select from following");
				System.out.println("Enter 1 for add coind details ");
				System.out.println("Enter 2 for Display Coin details");
				System.out.println("Enter 3 for add data from file");
				System.out.println("Enter 4 create list or search coin");
				System.out.println("Enter 6 for exit from application");
				n=sc.nextInt();
				switch(n) {
				case 1:
				{
					String Den;
					//int count=1;
					String Country;
					String Year;
					String Current_Value;
					String Acquired_date;
					
					System.out.println("Enter Denomination of coin:");
					Den=sc.next();
					Coins.add(Den);
					
					System.out.println("Enter Country name:");
					Country=sc.next();
					Coins.add(Country);
					CntList.add(Country);
					
					
					System.out.println("Enter Year of Minting:");
					Year=sc.next();
					Coins.add(Year);
					YOmList.add(Year);
					
					System.out.println("Enter Current Value:");
					Current_Value=sc.next();
					Coins.add(Current_Value);
					CurrentValueList.add(Current_Value);
					
					System.out.println("Enter Acquired date of coin:");
					Acquired_date=sc.next();
					Coins.add(Acquired_date);
					
					
				}
				break;
				case 2:{
					System.out.println("[Denomination,Country,Year_of_minting,current_value,acquired_date]");
					System.out.println(Coins);
					
				}
				break;
                case 3:{
                	
                	String line1 =null;  
					//String splitBy = ","; 
					BufferedReader br = new BufferedReader(new FileReader("H:\\CoinFile.csv")); 
					//int count=0;
					br.readLine();
					while ((line1 = br.readLine()) != null) {
						//System.out.println(line);
						String[] Cn=line1.split(",");
						//System.out.println(Cn);
						String Den=Cn[0];
						String Cntry=Cn[1];
						String Yom=Cn[2];
						String Cv=Cn[3];
						String Aqd=Cn[4];
						  Coins.add(Den);
						  
						  Coins.add(Cntry);
						  CntList.add(Cntry);
						  
						  Coins.add(Yom);
						  YOmList.add(Yom);
						  
						  Coins.add(Cv);
						  CurrentValueList.add(Cv);
						  
						  Coins.add(Aqd);
						  Coins.add("\n");
						System.out.println("Data has been inserted successfully");
						
					}
					br.close();
					
				}
				break;
                case 4:{
                	int b=0;
					do {
					   System.out.println("select from following");
					   System.out.println("1 for creating list");
					   System.out.println("2 for Searching ");
					   System.out.println("3 exit from Search and list section ");
					   b=sc.nextInt();
					   switch(b)
					   {
					   case 1:
					   {
						   int s=0;
				        	 do {
				        		 System.out.println("to Create list select one one of following:");
				        		 System.out.println("1 for create list by Country name");
				        		 System.out.println("2 for create list by year of minting");
				        		 System.out.println("3 for create list by Current values");
				        		 System.out.println("4 for exit from create listing");
				        		 s=sc.nextInt();
				        		 switch(s)
				        		 {
				        		 case 1:
				        		 {
				        		     
				        			 System.out.println(CntList);
				        			 
				        		 }
				        		 break;
				        		 case 2:
				        		 {
				        			 System.out.println(YOmList);
				        		 }
				        		 break;
				        		 case 3:
				        		 {
				        			 Collections.sort(CurrentValueList);
				        			 System.out.println("Coins values after sorting");
				        			 System.out.println(CurrentValueList);
				        		 }
				        		 break;
				        		 }
				        	 }while(s!=4);
						   
					   }
					   break;
					   
					   case 2:
					   {
						   int p=0;
						   do {
						   System.out.println("to search");
						   System.out.println("Enter 1 for search by country and denomination");
						   System.out.println("Enter 2 for search by Country and Year of minting");
						   System.out.println("Enter 3 for search by country + Denomination + yeaar of minting ");
						   System.out.println("Enter 4 for search by aquired date+country");
						   p=sc.nextInt();
						   switch(p)
						   {
						   case 1:
						   {
							   System.out.println("Enter Country name to search:");
							   String cns1=sc.next();
							   System.out.println("Enter Denomination(number on coin)");
							   String Den2=sc.next();
							   boolean found=false;
							   for(int i=0;i<Coins.size();i++)
							   {
								   if(Coins.get(i).equals(cns1) && Coins.get(i).equals(Den2));
								   {
									   found=true;
								   }
								   
							   }
							   if(found==false)
							   {
								   System.out.println("records not found");
							   }
							   else
							   {
								   System.out.println("Coin found");
							   }
							   
							   
							   
							   
							   
							   
							   
							   
						   }
						   break;
						   case 2:
						   {
							   System.out.println("Enter Country name to search:");
							   String cns1=sc.next();
							   System.out.println("Enter year of minting");
							   String Den2=sc.next();
							   boolean found=false;
							   for(int i=0;i<Coins.size();i++)
							   {
								   if(Coins.get(i).equals(cns1) && Coins.get(i).equals(Den2));
								   {
									   found=true;
								   }
								   
							   }
							   if(found==false)
							   {
								   System.out.println("records not found");
							   }
							   else
							   {
								   System.out.println("Coin found");
							   }
						   }
						   break;
						   case 3:
						   {
							   System.out.println("Enter Country name to search:");
							   String cns1=sc.next();
							   System.out.println("Enter Denomination(number on coin)");
							   String Den2=sc.next();
							   System.out.println("Enter year of minting");
							   String Den3=sc.next();
							   boolean found=false;
							   for(int i=0;i<Coins.size();i++)
							   {
								   if(Coins.get(i).equals(cns1) && Coins.get(i).equals(Den2) && Coins.equals(Den3));
								   {
									   found=true;
								   }
								   
							   }
							   if(found==false)
							   {
								   System.out.println("records not found");
							   }
							   else
							   {
								   System.out.println("Coin found");
							   }
							   
							   
						   }
						   break;
						   case 4:
						   {
							   System.out.println("Enter aquired date to search:");
							   String cns1=sc.next();
							   System.out.println("Enter country name");
							   String Den2=sc.next();
							   boolean found=false;
							   for(int i=0;i<Coins.size();i++)
							   {
								   if(Coins.get(i).equals(cns1) && Coins.get(i).equals(Den2));
								   {
									   found=true;
								   }
								   
							   }
							   if(found==false)
							   {
								   System.out.println("records not found");
							   }
							   else
							   {
								   System.out.println("Coin found");
							   }
							   
							   
						   }
						   break;
						   }
						   
						   }while(p!=4);
					   }
					   break;
					   }
					   
					}while(b!=3);
	
                }
                break;
                case 5:{
                	
	
                }
                break;
				}
				
			}while(n!=6);
			

//			String sql2 = "DELETE FROM Coins ";
//			sdmt.execute(sql2);
			String Coins1[] =Coins.toArray(new String[Coins.size()]);
			
			while (Coins1!= null) {
				//System.out.println(line);
				//String[] Cn=line.split(",");
				//System.out.println(Cn);
				String Den=Coins1[0];
				String Cntry=Coins1[1];
				String Yom=Coins1[2];
				String Cv=Coins1[3];
				String Aqd=Coins1[4];
				  sdmt.setInt(1,parseInt(Den));
				  sdmt.setString(2,Cntry);
				  sdmt.setString(3,Yom);
			      sdmt.setInt(4,parseInt(Cv));
				  sdmt.setString(5,Aqd);
				  
						 
				  sdmt.execute();								System.out.println("Data has been inserted successfully");
				
			}
		 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //8.0.31 connector j 
         catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			

	}

}
